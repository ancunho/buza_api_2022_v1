package buza.group.api.service;

import java.util.List;
import java.util.Map;

public interface HelloService {

    public List<Map<String, Object>> getAllSysUser();

}
