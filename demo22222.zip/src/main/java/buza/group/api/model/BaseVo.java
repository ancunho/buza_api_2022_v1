package buza.group.api.model;

import java.io.Serializable;

public class BaseVo implements Serializable {
}
