package buza.group.api.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class SysMenuVo implements Serializable {

    private Integer id;
    private Integer parentId;
    private String name;
    private String path;
    private String perms;
    private String component;
    private Integer type;
    private String typeName;
    private String icon;
    private String title;
    private Integer orderNum;
    private String status;
    private String statusName;
    private String createtime;
    private String updatetime;
    List<SysMenuVo> children = new ArrayList<>();

}
