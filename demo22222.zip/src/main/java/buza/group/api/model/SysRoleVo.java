package buza.group.api.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
public class SysRoleVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;
    private String name;
    private String code;
    private String remark;
    private String status;
    private String statusName;
    private String createtime;
    private String updatetime;

    private List<SysMenuVo> sysMenuVoList;

}
