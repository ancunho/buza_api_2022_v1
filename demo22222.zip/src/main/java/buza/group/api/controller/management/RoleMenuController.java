package buza.group.api.controller.management;

import buza.group.api.common.ServerResponse;
import buza.group.api.entity.SysUser;
import buza.group.api.model.SysMenuVo;
import buza.group.api.model.SysRoleVo;
import buza.group.api.service.RoleMenuService;
import buza.group.api.service.SysUserService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Getter
@Setter
@AllArgsConstructor
@RestController
@RequestMapping(value = "/api/v1/mgt/system")
@Api(value = "权限菜单管理", tags = "权限菜单管理")
@ApiSupport(order = 2)
public class RoleMenuController {

    @Autowired
    private RoleMenuService roleMenuService;

    @Autowired
    private SysUserService sysUserService;

    /**
     * Sys메뉴리스트가져오기
     * @return
     */
    @GetMapping(value = "/menu/list")
    @ApiOperation(value = "菜单列表", notes = "获取全部菜单列表")
    @ApiOperationSupport(order = 200)
    public ServerResponse<List<SysMenuVo>> getAllSysMenuList() {
        List<SysMenuVo> lstSysMenuVo = roleMenuService.getAllSysMenuList();
        return ServerResponse.createBySuccess(lstSysMenuVo);
    }

    // TODO 메뉴추가 path: /menu/add
    // TODO 메뉴수정 path: /menu/edit/{menuId}
    // TODO 메뉴삭제 path: /menu/delete/{menuId}



    /**
     * @TODO 전체권한리스트 가져오기
     */
    @GetMapping(value = "/role/list")
    @ApiOperation(value = "权限列表", notes = "获取全部权限列表")
    @ApiOperationSupport(order = 300)
    public ServerResponse<List<SysRoleVo>> getSysRoleList() {
        return ServerResponse.createBySuccess();
    }


    // TODO 권한추가 path: /role/add
    @GetMapping(value = "/role/add")
    @ApiOperation(value = "권한추가", notes = "권한추가")
    @ApiOperationSupport(order = 301)
    public ServerResponse<List<SysRoleVo>> insertSysRole() {
        return null;
    }
    // TODO 권한수정 path: /role/edit/{roleId}
    // TODO 권한삭제 path: /role/delete/{roleId}


    public ServerResponse<List<SysMenuVo>> getSysMenuListByRoleId(@RequestParam("asdf") Integer roleId) {
        return null;
    }


}
